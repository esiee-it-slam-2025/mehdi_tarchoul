from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from ..models import Event, Team

@login_required
@user_passes_test(lambda u: u.is_superuser)
def admin_events(request):
    if request.method == 'POST':
        event_id = request.POST.get('event_id')
        winner_name = request.POST.get('winner')  # Nom de l'équipe gagnante
        stadium = request.POST.get('stadium')  # Nouveau stade
        start = request.POST.get('start')  # Nouvelle date

        try:
            event = Event.objects.get(id=event_id)

            # Mettre à jour le stade si fourni
            if stadium:
                event.stadium = stadium

            # Mettre à jour la date si fournie
            if start:
                event.start = start

            # Mettre à jour le vainqueur si fourni
            if winner_name:
                winner = Team.objects.get(name=winner_name)
                event.winner = winner

                # Si le match est un match de groupe, passer à l'étape suivante (quarts)
                if event.stage == "Groupe":
                    event.stage = "Quarts"
                    assign_team_to_next_stage(winner, "Quarts")

                # Si le match est un match de quarts, passer à l'étape suivante (demi)
                elif event.stage == "Quarts":
                    event.stage = "Demi"
                    assign_team_to_next_stage(winner, "Demi")

                # Si le match est un match de demi, passer à l'étape suivante (finale)
                elif event.stage == "Demi":
                    event.stage = "Finale"
                    assign_team_to_next_stage(winner, "Finale")

                # Si le match est une finale, marquer comme terminé
                elif event.stage == "Finale":
                    event.stage = "Terminé"

            else:
                event.winner = None  # Si aucun vainqueur n'est sélectionné

            event.save()
            messages.success(request, "Événement mis à jour avec succès.")
        except Event.DoesNotExist:
            messages.error(request, "Match non trouvé.")
        except Team.DoesNotExist:
            messages.error(request, "Équipe non trouvée.")

        return redirect('admin_events')

    events = Event.objects.all()
    return render(request, 'admin/events.html', {'events': events})

def assign_team_to_next_stage(team, next_stage):
    """
    Assigner une équipe à un match de l'étape suivante.
    """
    # Vérifier si l'équipe est déjà dans un match de l'étape suivante
    existing_match = Event.objects.filter(
        stage=next_stage,
        team_home=team
    ).exists() or Event.objects.filter(
        stage=next_stage,
        team_away=team
    ).exists()

    if not existing_match:
        # Trouver un match de l'étape suivante disponible et assigner l'équipe
        next_match = Event.objects.filter(stage=next_stage, team_home__isnull=True).first()
        if next_match:
            next_match.team_home = team
            next_match.save()
        else:
            next_match = Event.objects.filter(stage=next_stage, team_away__isnull=True).first()
            if next_match:
                next_match.team_away = team
                next_match.save()
    else:
        # Gérer le cas où l'équipe est déjà dans un match de l'étape suivante
        # Par exemple, afficher un message d'erreur ou ignorer l'assignation
        pass