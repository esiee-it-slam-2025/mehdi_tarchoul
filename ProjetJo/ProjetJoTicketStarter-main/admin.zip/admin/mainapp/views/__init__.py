# Pour chaque fichier de vue, il faut en importer toutes les variables ici
from .api import *
